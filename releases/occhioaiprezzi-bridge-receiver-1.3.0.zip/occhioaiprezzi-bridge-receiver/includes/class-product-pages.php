<?php
defined('ABSPATH') || exit;
final class OAP_Product_Pages {
    public static function validate(array $p, string $gtin): array {
        OAP_Support::gtin($gtin);
        foreach (['protocol','gtin','slug','version','content_hash','html','seo','state','redirects','removal_policy','operation'] as $key) {
            if (!array_key_exists($key, $p)) { throw new OAP_Failure('oap_missing_field'); }
        }
        if ($p['protocol'] !== 'oap-wp-1' || $p['gtin'] !== $gtin || !is_int($p['version']) || $p['version'] < 1
            || !is_string($p['content_hash']) || !preg_match('/\A[a-f0-9]{64}\z/', $p['content_hash'])
            || !in_array($p['state'], ['active','inactive'], true) || !in_array($p['removal_policy'], ['gone','temporary'], true)
            || !in_array($p['operation'], ['create','update'], true) || !is_string($p['html']) || !is_array($p['seo']) || array_is_list($p['seo']) || !is_array($p['redirects']) || !array_is_list($p['redirects']) || count($p['redirects']) > 500) {
            throw new OAP_Failure('oap_invalid_payload');
        }
        OAP_Support::slug($p['slug']);
        foreach ($p['redirects'] as $s) { OAP_Support::slug($s); }
        $p['redirects'] = array_values(array_unique($p['redirects']));
        if (str_contains($p['html'], '<?')) { throw new OAP_Failure('oap_unsafe_html'); }
        $processor = new WP_HTML_Tag_Processor($p['html']);
        while ($processor->next_tag()) {
            if (in_array($processor->get_tag(), ['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','SVG','MATH','FORM','INPUT','LINK','META','BASE'], true)
                || $processor->get_attribute_names_with_prefix('on')) { throw new OAP_Failure('oap_unsafe_html'); }
            foreach (['href', 'src'] as $attr) {
                $url = $processor->get_attribute($attr);
                if ($url !== null) { OAP_Support::url($url); }
            }
        }
        $allowed = [];
        foreach (['article','section','div','span','p','h1','h2','h3','strong','em','ul','ol','li','br','table','caption','thead','tbody','tr','th','td'] as $tag) {
            $allowed[$tag] = ['class'=>true];
        }
        $allowed['a'] = ['href'=>true,'rel'=>true,'title'=>true];
        $allowed['img'] = ['src'=>true,'alt'=>true,'loading'=>true,'width'=>true,'height'=>true];
        // Validate without rewriting the VPS document. Reject unsupported markup.
        if (wp_kses($p['html'], $allowed, ['http','https']) !== $p['html']) { throw new OAP_Failure('oap_unsafe_html'); }
        $seo = $p['seo'];
        if (!isset($seo['indexable'], $seo['modified_at']) || !is_bool($seo['indexable']) || !is_int($seo['modified_at']) || $seo['modified_at'] < 0
            || (isset($seo['gtin']) && $seo['gtin'] !== $gtin)) { throw new OAP_Failure('oap_invalid_seo'); }
        foreach (['title','description','canonical','h1','brand','image','category'] as $field) {
            if (isset($seo[$field]) && (!is_string($seo[$field]) || strlen($seo[$field]) > 4096)) { throw new OAP_Failure('oap_invalid_seo'); }
        }
        if (empty($seo['title']) || !is_string($seo['canonical'] ?? null)) { throw new OAP_Failure('oap_invalid_seo'); }
        OAP_Support::url($seo['canonical']);
        if ($p['state'] === 'inactive' && $seo['indexable']) { throw new OAP_Failure('oap_invalid_seo'); }
        if (!empty($seo['image'])) { OAP_Support::url($seo['image']); }
        if (isset($seo['jsonld']) && (!is_array($seo['jsonld']) || array_is_list($seo['jsonld']))) { throw new OAP_Failure('oap_invalid_jsonld'); }
        if (isset($seo['jsonld'])) { self::validate_jsonld($seo['jsonld']); }
        if (array_key_exists('affiliate_destinations', $p)) {
            $entries = $p['affiliate_destinations'];
            if (!is_array($entries) || !array_is_list($entries) || count($entries) > 500) { throw new OAP_Failure('oap_invalid_affiliate_destinations'); }
            $seen = [];
            foreach ($entries as $entry) {
                if (!is_array($entry) || count($entry) !== 2 || !is_string($entry['code'] ?? null)
                    || !preg_match('/\A[A-Za-z0-9_-]{43}\z/', $entry['code'])
                    || isset($seen[$entry['code']]) || OAP_Affiliate_Redirects::destination($entry['destination_url'] ?? null) === null
                    || !OAP_Affiliate_Redirects::public_host($entry['destination_url'])) {
                    throw new OAP_Failure('oap_invalid_affiliate_destinations');
                }
                $seen[$entry['code']] = true;
            }
        }
        unset($p['eligibility_proof']);
        return $p;
    }
    private static function validate_jsonld(array $node, int $depth = 0): void {
        if ($depth > 20) { throw new OAP_Failure('oap_invalid_jsonld'); }
        foreach ($node as $key => $value) {
            if (in_array($key, ['url','image','@context','availability'], true) && is_string($value)) { OAP_Support::url($value); }
            if (is_array($value)) { self::validate_jsonld($value, $depth + 1); }
        }
    }
    /** Private artifacts retain fingerprints for idempotency, never the affiliate URLs. */
    private static function private_snapshot(array $p): array {
        if (array_key_exists('affiliate_destinations', $p)) {
            foreach ($p['affiliate_destinations'] as &$entry) {
                $entry = ['code'=>$entry['code'], 'destination_sha256'=>hash('sha256', $entry['destination_url'])];
            }
            unset($entry);
        }
        return $p;
    }
    private static function same_document(array $p, array $row): void {
        $old = OAP_Storage::read($row['artifact']);
        $p = self::private_snapshot($p);
        foreach (['operation','version','content_hash','eligibility_proof'] as $key) { unset($old[$key], $p[$key]); }
        if (!array_key_exists('affiliate_destinations', $p)) { unset($old['affiliate_destinations']); }
        // Opaque Ponte hashes cannot authorize a different document on retry/cursor advance.
        if (self::ordered($old) !== self::ordered($p)) { throw new OAP_Failure('oap_hash_conflict', 409); }
    }
    private static function ordered(array $value): array {
        if (!array_is_list($value)) { ksort($value); }
        foreach ($value as &$item) { if (is_array($item)) { $item = self::ordered($item); } }
        unset($item);
        return $value;
    }
    public static function ack(string $gtin, ?array $row, string $operation = 'managed'): array {
        if ($row && $row['owner'] !== 'oap-wp-1') { throw new OAP_Failure('oap_foreign_owner', 409); }
        return ['gtin'=>$gtin, 'version'=>$row ? (int)$row['version'] : 0, 'installed_hash'=>$row['installed_hash'] ?? '',
            'remote_id'=>$row ? 'oap:' . $gtin : '', 'ownership'=>$row ? 'bridge' : 'absent', 'operation'=>$row ? $operation : 'absent'];
    }
    public static function put(array $p, string $gtin): array {
        global $wpdb;
        if (OAP_Support::cfg('OAP_BRIDGE_WRITES_ENABLED', false) !== true) { throw new OAP_Failure('oap_writes_disabled', 503); }
        $p = self::validate($p, $gtin); $db = new OAP_Storage();
        $result = $db->locked(static function ($db) use ($p, $gtin, $wpdb) {
            $row = $db->page($gtin);
            self::ack($gtin, $row);
            if ($row && $p['version'] < (int)$row['version']) { throw new OAP_Failure('oap_remote_ahead', 409); }
            if ($row && $p['version'] === (int)$row['version']) {
                if (!hash_equals($row['installed_hash'], $p['content_hash'])) { throw new OAP_Failure('oap_version_conflict', 409); }
                self::same_document($p, $row);
                return self::ack($gtin, $row, 'unchanged');
            }
            if ($p['operation'] === 'create' && $row) { throw new OAP_Failure('oap_page_exists', 409); }
            if ($p['operation'] === 'update' && !$row) { throw new OAP_Failure('oap_page_absent', 409); }
            if ($row && hash_equals($row['installed_hash'], $p['content_hash'])) {
                self::same_document($p, $row);
                $db->query($wpdb->prepare("UPDATE `{$db->pages}` SET version=%d WHERE gtin=%s", $p['version'], $gtin));
                $row['version'] = $p['version'];
                return self::ack($gtin, $row, 'cursor_advanced');
            }
            $slugs = array_values(array_unique(array_merge($p['redirects'], [$p['slug']])));
            foreach ($slugs as $slug) {
                $claim = $db->one($wpdb->prepare("SELECT gtin FROM `{$db->slugs}` WHERE slug=%s", $slug));
                if ($claim && $claim['gtin'] !== $gtin) { throw new OAP_Failure('oap_slug_conflict', 409); }
                // Fail closed on native content; receiver never assumes ownership of posts.
                if ($db->one($wpdb->prepare("SELECT ID FROM `{$wpdb->posts}` WHERE post_name=%s AND post_type NOT IN ('revision','attachment') LIMIT 1", $slug))) {
                    throw new OAP_Failure('oap_foreign_page', 409);
                }
            }
            $artifact = OAP_Storage::artifact(self::private_snapshot($p));
            if (array_key_exists('affiliate_destinations', $p)) { $db->sync_affiliates($gtin, $p['affiliate_destinations']); }
            foreach ($slugs as $slug) {
                $db->query($wpdb->prepare("INSERT INTO `{$db->slugs}` (slug,gtin) VALUES (%s,%s) ON DUPLICATE KEY UPDATE gtin=VALUES(gtin)", $slug, $gtin));
            }
            if ($p['operation'] === 'create') {
                $db->query($wpdb->prepare("INSERT INTO `{$db->pages}` (gtin,owner,version,installed_hash,slug,artifact,state,indexable,modified_at)
                    VALUES (%s,'oap-wp-1',%d,%s,%s,%s,%s,%d,%d)",
                    $gtin,$p['version'],$p['content_hash'],$p['slug'],$artifact,$p['state'],$p['seo']['indexable']?1:0,$p['seo']['modified_at']));
            } else {
                $db->query($wpdb->prepare("UPDATE `{$db->pages}` SET version=%d,installed_hash=%s,slug=%s,artifact=%s,state=%s,indexable=%d,modified_at=%d
                    WHERE gtin=%s AND owner='oap-wp-1'",
                    $p['version'],$p['content_hash'],$p['slug'],$artifact,$p['state'],$p['seo']['indexable']?1:0,$p['seo']['modified_at'],$gtin));
            }
            return self::ack($gtin, $db->page($gtin), $p['operation'] === 'create' ? 'created' : 'updated');
        });
        if (in_array($result['operation'], ['created','updated'], true)) {
            // Integrate site-specific CDN invalidation without a full-catalog purge.
            do_action('oap_bridge_page_changed', $gtin, OAP_Support::canonical($p['slug']), $p['redirects']);
        }
        return $result;
    }
}

